# CSV Cleaner

A small Python tool that turns a messy CSV file into a clean Excel file.

## What it fixes
- Messy column names (` Customer Name ` becomes `customer_name`)
- Extra spaces and inconsistent capitalization in names and cities
- Invalid or uppercase email addresses
- Phone numbers in many formats (standardized to `555-123-4567`)
- Dates written in different styles (standardized to `YYYY-MM-DD`)
- Currency text like `$1,200.50` (converted to numbers)
- Completely empty rows and duplicate records
- Missing text values (filled with `Unknown`)

It prints a short summary of what it changed.

## How to run
```
pip install -r requirements.txt
python clean_csv.py messy_customers.csv -o cleaned_customers.xlsx
```

## Example
Input: `messy_customers.csv` (8 rows, with blanks and duplicates)
Output: `cleaned_customers.xlsx` (5 clean rows)

## Built with
Python, pandas, openpyxl
